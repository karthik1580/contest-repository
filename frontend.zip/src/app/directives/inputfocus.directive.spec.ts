import { InputfocusDirective } from './inputfocus.directive';

describe('InputfocusDirective', () => {
  it('should create an instance', () => {
    const directive = new InputfocusDirective();
    expect(directive).toBeTruthy();
  });
});
