import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { LocationrepoService } from '../../shared/locationrepo.service';
import { Locationrepo } from '../../shared/locationrepo.model';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.sass'],
  providers: [LocationrepoService]
})
export class LocationComponent implements OnInit {
  Admin: boolean = true;
  show: boolean = true;
  constructor(private locationrepoService: LocationrepoService) { }

  ngOnInit() {
    this.resetForm();
    this.getRefreshLocationList();
  }

  onContentedit(form: NgForm){
    console.log("this", this);
  }

  resetForm(form?: NgForm){
    if(form)
      form.reset();
      this.locationrepoService.selectedLocationrepos = {
      _id: "",
      title: "",
      childran: []
    }
  }
  onSubmitTitle(form: NgForm){
    this.locationrepoService.postTitles(form.value).subscribe((res) => {
      this.resetForm(form);
      alert("Successfully created");
      this.getRefreshLocationList();
    })
  }
  
  onSubmitSubMenu(form: NgForm){

    // this.locationrepoService.postMyLocation(form.value).subscribe((res) => {
    //   this.resetForm(form);
    //   alert("Successfully created");
    //   this.getRefreshLocationList();
    // })
  }

  getRefreshLocationList(){
    this.locationrepoService.getLocationList().subscribe((res) => {
      this.locationrepoService.locationrepo = res as Locationrepo[];
    });
  }

  onEdit(loc: Locationrepo) {
    this.locationrepoService.selectedLocationrepos = loc;
    this.getRefreshLocationList();
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.locationrepoService.deleteLocationMenu(_id).subscribe((res) => {
        this.getRefreshLocationList();
        this.resetForm(form);
      });
    }
  }

}
