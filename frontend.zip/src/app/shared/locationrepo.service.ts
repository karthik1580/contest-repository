import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
//import 'rxjs/add/operator/map';
//import 'rxjs/add/operator/toPromise';


import { Locationrepo } from './locationrepo.model';

@Injectable({
  providedIn: 'root'
})
export class LocationrepoService {
  selectedLocationrepos: Locationrepo;
  locationrepo: Locationrepo[];
  readonly baseUrl = 'http://localhost:3000/locationrepo';
  // selectedLocationrepos: Locreposkarthik;
  // locationrepo: Locreposkarthik[];
  // readonly baseUrl = 'http://localhost:3000/locreposkarthiks';

  constructor( private http: HttpClient) { }

  postTitles(loc: Locationrepo) {
    return this.http.post(this.baseUrl, loc)
  }
  postMyLocation(loc: Locationrepo) {
    console.log("locloclocloc", loc);
    //return this.http.post(this.baseUrl, loc)
  }
  getLocationList() {
    return this.http.get(this.baseUrl);
  }
  putLocationMenu(loc: Locationrepo) {
    return this.http.put(this.baseUrl + `/${loc._id}`, loc);
  }
  deleteLocationMenu(_id: string) {
    console.log("_id_id_id_id", _id);
    return this.http.delete(this.baseUrl + `/${_id}`);
  }
}
