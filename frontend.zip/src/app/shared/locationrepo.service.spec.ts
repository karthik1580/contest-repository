import { TestBed } from '@angular/core/testing';

import { LocationrepoService } from './locationrepo.service';

describe('LocationserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LocationrepoService = TestBed.get(LocationrepoService);
    expect(service).toBeTruthy();
  });
});
