export class Locationrepo {
    _id: String;
    title: String;
    childran: [];
}
