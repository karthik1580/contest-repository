const express = require('express');
var router = express.Router();
var { LocRepo } = require('../models/locationrepo');
var ObjectId = require('mongoose').Types.ObjectId;

router.get('/', (req, res) => {
    LocRepo.find((err, data) => {
        if(!err)
            res.send(data);
        else
            console.log("Error in retriving data : " + JSON.stringify(err, undefind, 2));
    });
});
router.get('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id)){
        return res.status(400).send(`No record with given id : ${req.params.id}`);
    }
    LocRepo.findById(req.params.id, (err, data) => {
        if (!err) 
            res.send(data);
        else 
            console.log('Error in Retriving title :' + JSON.stringify(err, undefined, 2));
    });
});


router.post('/', (req, res) => {
    var menuTitle = new LocRepo({
        title: req.body.title
    });
    menuTitle.save((err, data) => {
        if(!err)
            res.send(data);
        else
            console.log("Error in retriving data: " + JSON.stringify(err, undefind, 2));
    });
});

router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    LocRepo.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error on Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var menuTitle = {
        title: req.body.title
    };
    LocRepo.findByIdAndUpdate(req.params.id, { $set: menuTitle }, { new: true }, (err, data) => {
        if (!err) { res.send(data); }
        else { console.log('Error in menu Update :' + JSON.stringify(err, undefined, 2)); }
    });
});

module.exports = router;