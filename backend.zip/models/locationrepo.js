const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

// const ChildranSchma = new Schema({
//     refId: ObjectId,
//     title: String,
//     refId: String
// });

var LocRepo = mongoose.model('Locationrepo', {
    title: {type: String}
});

module.exports = { LocRepo }; 

// const mongoose = require('mongoose');
// const Schema = mongoose.Schema;
// const ObjectId = Schema.Types.ObjectId;

// const ChildranSchma = new Schema({
//     refId: ObjectId,
//     title: String,
//     refId: String
// });
// const LocRepoSchma = new Schema({
//     title: String,
//     childran: [ChildranSchma]
// });

// const LocRepo = mongoose.model('locreposkarthik', LocRepoSchma);

// module.exports = { LocRepo };

